# SPDX-License-Identifier: GPL-3.0-or-later
"""
The in-Blender model browser: a searchable list of every ripped model, with a
plain-language description, that imports or adds the chosen one with a click.

Point it at a rips folder, hit Scan, then type in the search box -- "quiet",
"arm female", "hat", "respirator" -- and the matching models surface out of a
folder of terse filenames. Import a standalone model, or add one onto the active
character rig with the assembler.
"""

import bpy
from bpy.props import (CollectionProperty, EnumProperty, IntProperty,
                       StringProperty)

from . import assembler, catalog, discovery, importer, prefs
from .operators import LOG_TEXT_NAME, FoxImportSettings, _active_armature


class FOXB_CatalogItem(bpy.types.PropertyGroup):
    name: StringProperty()
    path: StringProperty()
    game: StringProperty()
    category: StringProperty()
    desc: StringProperty()
    gender: StringProperty()


class FOXB_UL_catalog(bpy.types.UIList):
    def draw_item(self, _context, layout, _data, item, _icon, _active, _prop, _index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.label(text=item.name, icon='OUTLINER_OB_ARMATURE')
            sub = row.row()
            sub.alignment = 'RIGHT'
            sub.label(text=item.desc)
        else:
            layout.label(text=item.name)

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        wm = context.window_manager
        term = (wm.foxb_cat_search or "").lower()
        game = wm.foxb_cat_game
        cat = wm.foxb_cat_category
        gender = wm.foxb_cat_gender
        flags = []
        for it in items:
            ok = True
            if term:
                ok = term in (it.name + " " + it.desc + " " + it.category).lower()
            if ok and game != 'ALL':
                ok = it.game == game
            if ok and cat != 'ALL':
                ok = it.category == cat
            if ok and gender != 'ALL':
                ok = (it.gender or "Unisex") == gender
            flags.append(self.bitflag_filter_item if ok else 0)
        return flags, []


class FOXB_OT_catalog_scan(bpy.types.Operator):
    """Scan the rips folder for models and describe them"""
    bl_idname = "foxbrowser.catalog_scan"
    bl_label = "Scan Rips Folder"
    bl_options = {'REGISTER'}

    def execute(self, context):
        wm = context.window_manager
        root = bpy.path.abspath(wm.foxb_cat_root)
        wm.foxb_cat_items.clear()
        found = catalog.scan(root)
        games = set()
        cats = set()
        for rec in found:
            it = wm.foxb_cat_items.add()
            it.name = rec["name"]; it.path = rec["path"]
            it.game = rec["game"]; it.category = rec["category"]; it.desc = rec["desc"]
            it.gender = rec.get("gender", "Unisex")
            games.add(rec["game"]); cats.add(rec["category"])
        _rebuild_category_items(cats)
        wm.foxb_cat_index = 0
        if not found:
            self.report({'WARNING'},
                        "No model FBXs found under that folder")
        else:
            self.report({'INFO'}, "found %d model(s) in %d game(s)"
                        % (len(found), len(games)))
        return {'FINISHED'}


def _selected(context):
    wm = context.window_manager
    idx = wm.foxb_cat_index
    if 0 <= idx < len(wm.foxb_cat_items):
        return wm.foxb_cat_items[idx]
    return None


class FOXB_OT_catalog_import(FoxImportSettings, bpy.types.Operator):
    """Import the selected model with the full FoxBrowser treatment"""
    bl_idname = "foxbrowser.catalog_import"
    bl_label = "Import Selected"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _selected(context) is not None

    def execute(self, context):
        item = _selected(context)
        if item is None:
            self.report({'ERROR'}, "nothing selected")
            return {'CANCELLED'}
        prefs.apply_defaults(self, context)
        self.import_animation = False        # a model, not a clip
        sets = discovery.gather_from_files([item.path])
        if not sets:
            self.report({'ERROR'}, "could not read %s" % item.name)
            return {'CANCELLED'}
        report = importer.Report()
        parent = importer.ensure_parent_collection(context, "")
        for es in sets:
            importer.import_set(context, es, self, report, parent)
        text = bpy.data.texts.get(LOG_TEXT_NAME) or bpy.data.texts.new(LOG_TEXT_NAME)
        text.clear(); text.write(report.as_text() or "Imported.")
        self.report({'INFO'}, "imported %s" % item.name)
        return {'FINISHED'}


class FOXB_OT_catalog_add(FoxImportSettings, bpy.types.Operator):
    """Add the selected model onto the active character rig"""
    bl_idname = "foxbrowser.catalog_add"
    bl_label = "Add to Active Character"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _selected(context) is not None and _active_armature(context) is not None

    def execute(self, context):
        item = _selected(context)
        master = _active_armature(context)
        if item is None or master is None:
            self.report({'ERROR'}, "select a model and an active character rig")
            return {'CANCELLED'}
        prefs.apply_defaults(self, context)
        self.import_animation = False
        coll = master.users_collection[0] if master.users_collection else None
        lines = []
        res = assembler.add_parts(master, [item.path], report=lines.append,
                                  link_collection=coll, settings=self)
        text = bpy.data.texts.get(LOG_TEXT_NAME) or bpy.data.texts.new(LOG_TEXT_NAME)
        text.clear(); text.write("\n".join(lines) or "Added.")
        for o in context.selected_objects:
            o.select_set(False)
        master.select_set(True)
        context.view_layer.objects.active = master
        self.report({'INFO'}, "added %s (%d bone(s) merged)"
                    % (item.name, res.bones_merged))
        return {'FINISHED'}


class FOXB_PT_catalog(bpy.types.Panel):
    bl_idname = "FOXB_PT_catalog"
    bl_label = "Model Browser"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "FoxBrowser"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        row = layout.row(align=True)
        row.prop(wm, "foxb_cat_root", text="")
        row.operator("foxbrowser.catalog_scan", text="", icon='FILE_REFRESH')

        n = len(wm.foxb_cat_items)
        if n == 0:
            layout.label(text="Set your models folder, then Scan", icon='INFO')
            return

        layout.prop(wm, "foxb_cat_search", text="", icon='VIEWZOOM')
        row = layout.row(align=True)
        row.prop(wm, "foxb_cat_game", text="")
        row.prop(wm, "foxb_cat_category", text="")
        layout.prop(wm, "foxb_cat_gender", text="")
        layout.template_list("FOXB_UL_catalog", "", wm, "foxb_cat_items",
                             wm, "foxb_cat_index", rows=8)

        item = _selected(context)
        if item is not None:
            box = layout.box()
            box.scale_y = 0.85
            box.label(text=item.name, icon='OUTLINER_OB_ARMATURE')
            box.label(text=item.desc)
            box.label(text=item.game)

        col = layout.column(align=True)
        col.scale_y = 1.2
        col.operator("foxbrowser.catalog_import", icon='IMPORT')
        add = col.row(align=True)
        add.enabled = _active_armature(context) is not None
        add.operator("foxbrowser.catalog_add", icon='ADD')
        if _active_armature(context) is None:
            r = layout.row(); r.scale_y = 0.8
            r.label(text="select a rig to enable 'Add'", icon='INFO')


class FOXB_PT_howto(bpy.types.Panel):
    bl_idname = "FOXB_PT_howto"
    bl_label = "How to Assemble a Character"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "FoxBrowser"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, _context):
        layout = self.layout
        col = layout.column(align=True)
        col.scale_y = 0.85
        for line in (
            "Fox Engine builds a character from a",
            "base body plus parts on one skeleton.",
            "",
            "1. Model Browser: search a base body",
            "   (bsm0/bsf0 Survive, skl0 MGO),",
            "   Import Selected.",
            "2. Keep its armature selected.",
            "3. Search each part (head, arms,",
            "   legs, chest, armour, hat, hair)",
            "   and Add to Active Character.",
            "4. Select the rig, Rewire Materials",
            "   for the full texture treatment.",
            "",
            "Ground Zeroes characters are single",
            "models: just Import Selected.",
        ):
            col.label(text=line)


classes = (
    FOXB_CatalogItem,
    FOXB_UL_catalog,
    FOXB_OT_catalog_scan,
    FOXB_OT_catalog_import,
    FOXB_OT_catalog_add,
    FOXB_PT_catalog,
    FOXB_PT_howto,
)

_GAME_ITEMS = (
    ('ALL', "All games", ""),
    ("Metal Gear Survive", "Survive", ""),
    ("MGSV: The Phantom Pain / MGO", "TPP / MGO", ""),
    ("MGSV: Ground Zeroes", "Ground Zeroes", ""),
)

_GENDER_ITEMS = (
    ('ALL', "Any gender", ""),
    ("Male", "Male", ""),
    ("Female", "Female", ""),
    ("Unisex", "Unisex", ""),
)

# Category enum is rebuilt from whatever the scan found. Blender keeps no strong
# reference to enum item strings, so they are held here to avoid a crash.
_CATEGORY_ITEMS = [('ALL', "All categories", "")]


def _category_items(_self, _context):
    return _CATEGORY_ITEMS


def _rebuild_category_items(categories):
    global _CATEGORY_ITEMS
    _CATEGORY_ITEMS = [('ALL', "All categories", "")]
    for c in sorted(categories):
        _CATEGORY_ITEMS.append((c, c, ""))


def register_props():
    wm = bpy.types.WindowManager
    wm.foxb_cat_root = StringProperty(
        name="Models folder", subtype='DIR_PATH',
        description="Folder of ripped models to browse. Any folder works -- it "
                    "does not need to be called 'rips'; the scan walks it for "
                    "model FBXs")
    wm.foxb_cat_search = StringProperty(
        name="Search", description="Filter by name or description",
        options={'TEXTEDIT_UPDATE'})
    wm.foxb_cat_game = EnumProperty(name="Game", items=_GAME_ITEMS, default='ALL')
    wm.foxb_cat_category = EnumProperty(name="Category", items=_category_items)
    wm.foxb_cat_gender = EnumProperty(name="Gender", items=_GENDER_ITEMS,
                                      default='ALL')
    wm.foxb_cat_items = CollectionProperty(type=FOXB_CatalogItem)
    wm.foxb_cat_index = IntProperty(default=0)


def unregister_props():
    wm = bpy.types.WindowManager
    for attr in ("foxb_cat_root", "foxb_cat_search", "foxb_cat_game",
                 "foxb_cat_category", "foxb_cat_gender",
                 "foxb_cat_items", "foxb_cat_index"):
        if hasattr(wm, attr):
            delattr(wm, attr)
